cordova-3-angular
=================

Sample project for setting up Cordova 3 with a yeoman+angular application
