#/bin/bash

cordova create c3c --link-to=c3a/app  #KEY ARGUMENT --link-to
cd c3c
cordova platform add android
