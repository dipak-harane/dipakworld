angular.module('uiGmapgoogle-maps.wrapped')
.service('uiGmapuuid', function() {
  //BEGIN REPLACE
  /* istanbul ignore next */
  @@REPLACE_W_LIBS
  //END REPLACE
return UUID;
});
