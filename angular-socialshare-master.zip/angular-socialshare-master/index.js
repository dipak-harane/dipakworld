﻿(function commonJS(require, module) {
    'use strict';

    require('./lib/angular-socialshare');

    module.exports = '720kb.socialshare';
}(require, module));
