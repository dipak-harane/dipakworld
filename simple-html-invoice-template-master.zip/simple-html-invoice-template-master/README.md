# Simple HTML invoice template
A modern, clean, and very simple responsive HTML invoice template, because sometimes you just need something quick and simple.

### Demo
[Find a demo here](http://www.nextstepwebs.com/examples/invoice)


### How to use
Open invoice.html and use the HTML and CSS provided inside in your application. Everything is contained within a `.invoice-box` divider.

### Preview
![Preview](http://www.nextstepwebs.com/examples/invoice.png)

### Suggestions?
Open an issue, and provide as much detail as possible.
