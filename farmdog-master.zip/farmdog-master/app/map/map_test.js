'use strict';

describe('mapApp.map module', function() {

  // add tests
});