angular.module('mapApp.panel', [])
.directive('panel', function() {
	return {
		templateUrl: 'map/panel.html'
	};
});