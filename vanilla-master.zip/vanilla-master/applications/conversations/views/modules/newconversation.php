<?php if (!defined('APPLICATION')) exit();
echo anchor(t('New Message'), '/messages/add', 'Button BigButton NewConversation Primary');
