<?php if (!defined('APPLICATION')) exit();
?>
<div class="Title">
    <h1><?php echo t("Vanilla is installed!"); ?></h1>
</div>
<div class="Form">
    <ul>
        <li><?php echo anchor(t('Click here to carry on.'), '/'); ?>.</li>
    </ul>
</div>
