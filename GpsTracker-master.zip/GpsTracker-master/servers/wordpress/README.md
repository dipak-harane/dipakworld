This is the wordpress plugin that I have in the Wordpress repository. You can see it here:

https://wordpress.org/plugins/gps-tracker/

It is MIT/GPLv2 or later licensed. I am using a dual license because most of the plugins in the Wordpress repo are GPLv2, as is Wordpress itself. My open source software is MIT licensed so it just made sense to dual license it.

Put the gps-tracker directory into your Plugins directory of your Wordpress installation and then activate the plugin. Go to the settings page to get the URL that you need to enter into your Android client. Here is the Android client in the Google Play store:

https://play.google.com/store/apps/details?id=com.websmithing.wp.gpstracker

