this is the javaMe / j2me client for gpstracker. This project was built with NetBeans 7.4 and java ME sdk 3.4.

use the websmithing defaultUploadWebsite:

https://www.websmithing.com/gpstracker/updatelocation.php

for testing 

change the *phoneNumber* form variable to something you know and then check your location with your browser here: 
 
https://www.websmithing.com/gpstracker/displaymap.php
