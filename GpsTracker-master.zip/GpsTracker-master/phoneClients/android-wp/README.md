This project was built with *android studio* and is close to the original version but uses GET instead of POST to update the wordpress plugin.
