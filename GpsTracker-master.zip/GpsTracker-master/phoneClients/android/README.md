This project was built with *android studio* and works fine with both servers. This version now supports google play location services in a background service. also will restart location updates if phone is rebooted.

This version is the same as the current version in the Google Play store.

https://play.google.com/store/apps/details?id=com.websmithing.gpstracker

for testing check your location with your browser here: 
 
https://www.websmithing.com/gpstracker/displaymap.php
