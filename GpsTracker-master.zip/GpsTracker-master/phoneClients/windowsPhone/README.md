This version of the windows phone client works fine with both servers. 

use the websmithing defaultUploadWebsite:

https://www.websmithing.com/gpstracker/updatelocation.php

for testing 

change the *phoneNumber* form variable to something you know and then check your location with your browser here: 
 
https://www.websmithing.com/gpstracker/displaymap.php