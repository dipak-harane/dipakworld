blogSample.controller('mainController', function($scope, $route){
  
    $scope.latitude = blogSample.latitude;
    $scope.longitude = blogSample.longitude;
                      
});

