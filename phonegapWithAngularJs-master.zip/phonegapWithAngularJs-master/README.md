# phonegapWithAngularJs

This is a hybrid mobile app built with PhoneGap, AngularJS, and Bootstrap

There is no functionality in it apart of showing your current location for the purpose of testing and demonstration.

The app code is explained in the blog post

http://arian-celina.com/developing-hybrid-mobile-apps-with-phonegap-angularjs-bootstrap