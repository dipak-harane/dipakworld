<?php

namespace YR\UsersBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class YRUsersBundle extends Bundle
{
}
